-- MySQL
USE hrproject;
SHOW TABLES;
