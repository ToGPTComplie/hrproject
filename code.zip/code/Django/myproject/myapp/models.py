from datetime import timezone
from django.db import models
from django.contrib.auth.hashers import make_password
from django.db.models import UniqueConstraint
from django.core.exceptions import ValidationError
import json

class EmployeeProfile(models.Model):
    employee_id = models.AutoField(primary_key=True)
    name = models.CharField(max_length=100)
    id_number = models.CharField(max_length=18, unique=True)
    age = models.PositiveIntegerField()
    current_hire_date = models.DateField()
    is_employed = models.BooleanField(default=True)

    def save(self, *args, **kwargs):
        # 自动处理重新入职逻辑
        if self.pk:
            orig = EmployeeProfile.objects.get(pk=self.pk)
            if not orig.is_employed and self.is_employed:
                self.current_hire_date = timezone.now().date()
        super().save(*args, **kwargs)

class EmploymentHistory(models.Model):
    record_id = models.AutoField(primary_key=True)
    id_number = models.ForeignKey(EmployeeProfile, to_field='id_number', on_delete=models.CASCADE)
    hire_date = models.DateField()
    leave_date = models.DateField(null=True, blank=True)
    leave_reason = models.CharField(max_length=200, blank=True)

class UserAccount(models.Model):
    employee = models.OneToOneField(EmployeeProfile, on_delete=models.CASCADE)
    account = models.CharField(max_length=50, unique=True)
    password = models.CharField(max_length=128)

    def set_password(self, raw_password):
        self.password = make_password(raw_password)

class Attendance(models.Model):
    ATTENDANCE_TYPE = [('in', '上班'), ('out', '下班')]
    
    employee = models.ForeignKey(EmployeeProfile, on_delete=models.CASCADE)
    date = models.DateField()
    type = models.CharField(max_length=3, choices=ATTENDANCE_TYPE)
    time = models.DateTimeField()

    class Meta:
        constraints = [
            UniqueConstraint(fields=['employee', 'date', 'type'], name='unique_attendance')
        ]

class Salary(models.Model):
    employee = models.ForeignKey(EmployeeProfile, on_delete=models.CASCADE)
    date = models.DateField()
    amount = models.DecimalField(max_digits=10, decimal_places=2)

    class Meta:
        unique_together = ('employee', 'date')

class Message(models.Model):
    message_id = models.AutoField(primary_key=True)
    employee = models.ForeignKey(EmployeeProfile, on_delete=models.CASCADE)
    timestamp = models.DateTimeField(auto_now_add=True)
    content = models.JSONField()
    is_read = models.BooleanField(default=False)
    msg_type = models.CharField(max_length=20)

class Department(models.Model):
    department_id = models.AutoField(primary_key=True)
    name = models.CharField(max_length=100)

class Position(models.Model):
    position_id = models.AutoField(primary_key=True)
    department = models.ForeignKey(Department, on_delete=models.CASCADE)
    title = models.CharField(max_length=100)

class EmployeeDepartment(models.Model):
    employee = models.ForeignKey(EmployeeProfile, on_delete=models.CASCADE)
    department = models.ForeignKey(Department, on_delete=models.CASCADE)
    position = models.ForeignKey(Position, on_delete=models.CASCADE)

    class Meta:
        unique_together = ('employee', 'department', 'position')

class Approval(models.Model):
    approval_id = models.AutoField(primary_key=True)
    employee = models.ForeignKey(EmployeeProfile, on_delete=models.CASCADE)
    content = models.JSONField()
    approval_type = models.CharField(max_length=20)

class JobApplication(models.Model):
    name = models.CharField(max_length=100)
    date = models.DateField()
    id_number = models.CharField(max_length=18)
    education = models.CharField(max_length=100)
    expected_department = models.ForeignKey(Department, on_delete=models.CASCADE)
    expected_position = models.ForeignKey(Position, on_delete=models.CASCADE)

    class Meta:
        unique_together = ('date', 'id_number', 'expected_department', 'expected_position')

class Task(models.Model):
    task_id = models.AutoField(primary_key=True)
    completion = models.PositiveIntegerField(validators=[MaxValueValidator(100)])
    content = models.JSONField()
    assigner = models.CharField(max_length=50, default='CEO')
    assign_time = models.DateTimeField(auto_now_add=True)
    start_time = models.DateTimeField()
    expected_end = models.DateTimeField()
    actual_end = models.DateTimeField(null=True, blank=True)

class TaskAssignment(models.Model):
    task = models.ForeignKey(Task, on_delete=models.CASCADE)
    employee = models.ForeignKey(EmployeeProfile, on_delete=models.CASCADE)

    class Meta:
        unique_together = ('task', 'employee')
        
# 在EmployeeProfile的save方法中处理
def save(self, *args, **kwargs):
    if self.pk:  # 更新操作
        orig = EmployeeProfile.objects.get(pk=self.pk)
        if not orig.is_employed and self.is_employed:  # 重新入职
            self.current_hire_date = timezone.now().date()
            # 创建雇佣历史记录
            EmploymentHistory.objects.create(
                id_number=self,
                hire_date=self.current_hire_date
            )
    super().save(*args, **kwargs)
    
# 在模型关系定义时指定
employee = models.OneToOneField(EmployeeProfile, on_delete=models.CASCADE)